// SAI VISHWAS PATHEM

#include <stdlib.h>
#include <netinet/in.h>
#include <stdio.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <sys/socket.h>

#include <string.h>

#include <unistd.h>

void* connnectionHandling(void* arg);
#define PORTNUMBER 1054  // Defining the Port Number
#define MAXIMUM_NUMBER_OF_CLIENTS 3 // Defing the maximun number of clients allowed
#define CAPACITY 1024        

pthread_mutex_t mutexLock;  // Declaring the Mutex Lock
FILE* sharedFile;


int main(int argc, char const *argv[]) {
    int server_fd, clientSocketId, opt = 1; // Declaring the Variables
    struct sockaddr_in socketAddress;
    int lenthofTheAddress = sizeof(socketAddress);
    char *ServerMsg = "Welcome to the server";  //Server Message
    char bufferArray[CAPACITY] = {0};
    int numberOfClients = 0;
    pthread_t threads[MAXIMUM_NUMBER_OF_CLIENTS];

    
      sharedFile = fopen("sharedFile.txt", "w"); // Creating the shared file in write mode
    if (sharedFile == NULL) {
        printf("CREATION OF FILE IS FAILED\n");
        return -1;
    }

    
    if (pthread_mutex_init(&mutexLock, NULL) != 0) {// Creating the mutex lock
        printf("Failed to create mutex mutexLock\n");
        return -1;
    }

    
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) {// Creating the server socket
        printf("Failed to create server socket\n");
        return -1;
    }
    
      if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &opt, sizeof(opt))) {// Setting the socket options
          printf("Failed to set socket options\n");
          return -1;
      }

      
      socketAddress.sin_family = AF_INET; // Binding server socket to the port number and socketAddress
      socketAddress.sin_addr.s_addr = INADDR_ANY;
      socketAddress.sin_port = htons(PORTNUMBER);
      if(bind(server_fd, (struct sockaddr *)&socketAddress, sizeof(socketAddress))<0) {
          printf("Failed to bind server socket\n");
          return -1;
      }

      
      if (listen(server_fd, MAXIMUM_NUMBER_OF_CLIENTS) < 0) {  // Started listening for the connections
          printf("Failed to start listening for connections\n");
          return -1;
      }

      printf("On the Port Number %d, Server is Started Listening\n", PORTNUMBER); // Prints the Port number with the server message
      
      while (numberOfClients < MAXIMUM_NUMBER_OF_CLIENTS) {
          if ((clientSocketId = accept(server_fd, (struct sockaddr *)&socketAddress, (socklen_t*)&lenthofTheAddress))<0) {// Accepting the connections and creating the respective threads to handle them
              printf("Unable to accept connection\n");
              continue;
          }
          
          printf("Connection got connected at %s:%d\n", inet_ntoa(socketAddress.sin_addr), ntohs(socketAddress.sin_port));  //Prints the Conection result message

          
          if (pthread_create(&threads[numberOfClients], NULL, connnectionHandling, (void*)&clientSocketId) != 0) { // Creating the thread to handle the connection
              printf("Unable to create a new thread\n");
              continue;
          }

          numberOfClients++;  // Incrementing the client count 
      }

      
      for (int val = 0; val <MAXIMUM_NUMBER_OF_CLIENTS; val++) {
             pthread_join(threads[val], NULL);  //pthread_join() function is used to wait for a thread to terminate.
  }

  
  fclose(sharedFile);
  pthread_mutex_destroy(&mutexLock); // Destroying the Mutex Object.

  return 0;
  }

void* connnectionHandling(void* arg) {    // Function to handle the Connection
    int clientSocketId = *(int*)arg;      //
    char bufferArray[CAPACITY] = {0};
    char bf[CAPACITY] = {0};
    int valueReaded = read(clientSocketId, bufferArray, CAPACITY);
    if(valueReaded < 0) {
        printf("MESSAGE FAILED TO RECEIVE FROM THE CLIENT\n");   
        return NULL;
    }
    pthread_mutex_lock(&mutexLock);      // Performing the Lock before entering in to the Critical Section
    fputs(bufferArray, sharedFile);      // Writing the Contents in to the shared file 
    fflush(sharedFile);               
    pthread_mutex_unlock(&mutexLock);     // Performing the Unlock 
    sleep(2);                               // Calling the Sleep system call
    FILE* fp;
    pthread_mutex_lock(&mutexLock); 
    fp=fopen("sharedFile.txt","r");         // Reading the file from the Shared File
    if (fp== NULL)
    {                                       //Cannot open the file
    printf("can not open file \n");         
    pthread_mutex_unlock(&mutexLock);         
    return NULL;
    }
    while (fgets(bf, 1024, fp)) {
        send(clientSocketId, bf, strlen(bf), 0);
        memset(bf, 0, sizeof(bf));
    }
    pthread_mutex_unlock(&mutexLock); 
    fclose(fp);
   
    send(clientSocketId, bufferArray, strlen(bufferArray), 0);       //Sending the contents of shared file to the client
    close(clientSocketId);
    return NULL;
}
