
    
//  SAI VISHWAS PATHEM  

 
 
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>

#define MAX_READERS_ALLOWED 14
#define NUM_READS 250000000
#define WRITER_UPDATED_MAXVALUE 25000

void relaxandspendingtime();
// shared variables
int counter = 0;
int in_cs = 0; // flag indicates whether the writer is in the critical section
int readerValue=0;

// semaphores
sem_t mutex, rw_mutex; // semaphores for write and read

// reader function
void *reader(void *arg) {
    int id = *(int *)arg;
    int i;
                //Entry section
    sem_wait(&mutex);  //Acquiring the mutex lock
    readerValue++;
     while(in_cs) {  
            printf("error at reader %d detected because writer is in critical section\n", id); 
        }
    if(readerValue==1){  // If this id is the first reader, then the writer would be blocked. 
        sem_wait(&rw_mutex);  //Acquiring the rwmutex lock
    }
        
        
        sem_post(&mutex);
        relaxandspendingtime();    // Critical Section
       // printf("Reader %d is in the critical section\n", id);
       sem_wait(&mutex);
        readerValue--;
        sem_post(&mutex);
        
         if(readerValue==0){ //If this id is the last reader, then the writer would be released to write/update. 
        sem_post(&rw_mutex); // Remainder Section
    }
    
    printf("Reader %d done\n", id);
    return NULL;   // Exit Section
}

//Reading/Accessing for 250000000 times function
void relaxandspendingtime() 
{
int i;
for(i = 0; i < 250000000; i++) 
counter;
}
// writer function
void *writer(void *arg) {
    int i;
    for (i = 0; i < WRITER_UPDATED_MAXVALUE; i++) {   //Entry section
        sem_wait(&rw_mutex);
        in_cs = 1;
        counter += 1; // Critical Section
        // update the value for demonstration purposes
        in_cs = 0;  // Remainder Section
        sem_post(&rw_mutex); // Exit Section
    }

    printf("Writer done\n");

    return NULL;
}

int main(int argc, char *argv[]) {
    int noOfReaders, i;
    pthread_t readers[MAX_READERS_ALLOWED], w;
    
    
    // parse command line argument
    if (argc < 2) {
        printf("Usage: %s num_readers\n", argv[0]);
        return 1;
    }
    /* Using the atoi function, converting string char to an integer */
    noOfReaders = atoi(argv[1]);
    int readers_array[noOfReaders];
    if (noOfReaders < 1 || noOfReaders > MAX_READERS_ALLOWED) {
        printf("Error: invalid number of readers\n");
        return 1;
    }
    
    // initialize semaphores
    sem_init(&mutex, 0, 1);
    sem_init(&rw_mutex, 0, 1);
    
   
    
    
    // Creating the first half Reader threads 
    for (i = 0; i < noOfReaders/2; i++) {
        readers_array[i] = i+1;
        pthread_create(&readers[i], NULL, reader, &readers_array[i]);
    }
         // Creating the writer thread
        pthread_create(&w, NULL, writer, NULL);

    // Creating the first half Reader threads 
    for (i = noOfReaders/2; i < noOfReaders; i++) {
        readers_array[i] = i+1;
        pthread_create(&readers[i], NULL, reader, &readers_array[i]);
    }
    
    // join threads

    for (i = 0; i < noOfReaders; i++) {   //It waits for each reader thread to terminate.
        pthread_join(readers[i], NULL);
    }
    pthread_join(w, NULL);  //It waits for writer thread to terminate.
    printf("Shared Variable updated as %d\n",counter);// Finally Printing the updated value
    
    // destroying both semaphores
    sem_destroy(&mutex);
    sem_destroy(&rw_mutex);
    
    return 0;
}
