#include<stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <stdlib.h>
#define bSize 20 //defining buffer size
#define items 30 
pthread_mutex_t mutexObject;
int incoming = 0;
int outgoing = 0;
int SUM[bSize];
int sum=0;

void *producerFunction(void *pno){
   int value;
   for(value=1;value<=items;value++)        //Entry section
   {
        pthread_mutex_lock(&mutexObject);         //It acquires a lock on the mutex object 
     while((incoming + 1) % bSize == outgoing) 
        { // buffer full
            pthread_mutex_unlock(&mutexObject);  //It releases the lock on the mutex object
             // It waits until there is at least one single slot free in the array buffer
            pthread_mutex_lock(&mutexObject);    //It acquires a lock on the mutex object 
        }
        SUM[incoming]=value;                     //Critical Section
    //    printf("Producers %d: Insert Item %d\n", *((int *)pno),SUM[in]);
        incoming=(incoming+1)%bSize;                    //Remainder Section
        pthread_mutex_unlock(&mutexObject);      //It releases the lock on the mutex object
    }
       pthread_exit(NULL);                  // Exit Section
}

void *consumerFunction(void *cno){
    int value;                          //Entry section
     for(value=1;value<=items;value++){ 
        pthread_mutex_lock(&mutexObject);          //It acquires a lock on the mutex object. 
        while (incoming == outgoing) {                  // buffer empty
            pthread_mutex_unlock(&mutexObject);    //It releases the lock on the mutex object.
            // It waits until there is at least one single item in the array buffer.
            pthread_mutex_lock(&mutexObject);     //It acquires a lock on the mutex object. 
        }
        int pickedvalue=SUM[outgoing];           //Critical Section
       // printf("Consumers %d: consuming item %d\n", *((int *)cno),pickedvalue);
        sum=sum+pickedvalue;
        outgoing=(outgoing+1)%bSize;                //Remainder Section
       pthread_mutex_unlock(&mutexObject);      //It releases the lock on the mutex object.  
       
}
    pthread_exit(NULL);                   // Exit Section
}

int main(){
    pthread_t producers[2],consumers[2];   // Declaring the Producer and Consumer Arrays
    pthread_mutex_init(&mutexObject, NULL);     //It initializes the mutex object.
    int tp_args[2],tc_args[2]; ; 
    for(int i = 0; i < 2; i++) {
        tp_args[i]=i;
        pthread_create(&producers[i], NULL, producerFunction, &tp_args[i]);  // It creates new thread for each producer.
    }
    for(int i = 0; i < 2; i++) {
        tc_args[i]=i;
        pthread_create(&consumers[i], NULL,consumerFunction,&tc_args[i]);    // It creates new thread for each consumer.
    }
for(int i = 0; i < 2; i++) {
        pthread_join(producers[i], NULL);     //It waits for each producer thread to terminate.
    }
    for(int i = 0; i < 2; i++) {
        pthread_join(consumers[i], NULL);     // //It waits for each consumer thread to terminate.
    }
printf("\nThe Sum Value is %d\n",sum);         // Prints the final output
    pthread_mutex_destroy(&mutexObject);           // Finally it destroyes the mutex object.
    return 0;
}
