//*********************

// SAI VISHWAS PATHEM

// ********************

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#define PAGE_SIZE 4096
#define PAGE_MASK 0xfff

void perform_FIF0(char *fileName, int frameSize);

void perform_LRU(char *fileName, int frameSize);

unsigned int checkforHexa(unsigned int value); 

 struct MainFrame
{                               // Declaring Variables
    unsigned int valuetoBeEntered;
    struct MainFrame *next;
    int recentlyUsed;
    int diskWrite;  // Dirty Bit Variable
};

struct MainFrame *head = NULL;
struct MainFrame *Current_Node = NULL;
void adding_Node(unsigned valuetoBeEntered)  // Function to add node into Frame
{
    struct MainFrame *new_Node = (struct MainFrame *)malloc(sizeof(struct MainFrame));
    new_Node->valuetoBeEntered = valuetoBeEntered;
    new_Node->recentlyUsed = 0;
    new_Node->diskWrite = 0;
    new_Node->next = head;
    head = new_Node;
}
int main(int argc, char *argv[])
{
     if(argc==4)
    {
        char nameoftheFile[strlen(argv[1])];   // Declaring Variables
        strcpy(nameoftheFile, argv[1]);
        int frameSize = atoi(argv[2]);
        char operation[strlen(argv[3])];
        strcpy(operation, argv[3]);
      //  char fifo[] = "fifo";
      if(strcmp(operation, "lru") == 0)      // Comparing the operation
            perform_LRU(nameoftheFile, frameSize);
        
        else if(strcmp(operation, "fifo") == 0)  // Comparing the operation
           perform_FIF0(nameoftheFile, frameSize);     
    }
    else  if (argc != 4)
        printf("Incorrect number of Arguments"); // Prints incorrect number of arguments
    
}

struct MainFrame *checkIfAlreadyPresent(int key, struct MainFrame *last)  // It checks if node is already present or not
{
    struct MainFrame *Current_Node = head;

    if (head == NULL)
        return NULL;
    

    while (Current_Node->valuetoBeEntered != key)  
    {

        if (Current_Node->valuetoBeEntered == last->valuetoBeEntered) // Comparing with all elements
        {
            if (Current_Node->valuetoBeEntered == key)
            {
                return Current_Node;       // Returns if node is found
            }
            else
            {
                return NULL;            // Returns null if node is not found
            }
        }
        else
        {
            Current_Node = Current_Node->next; 
        }
    }

    return Current_Node;  
}
void perform_FIF0(char *fileName, int frameSize)
{
    int diskReadCount = 0;// Declaring Variables
    int diskwriteCount = 0;
    unsigned int value;
    char operation;
    int pageFaults = 0;
     char input[20];
     char ip[5];


    int index = 0;
    FILE *filePointer;
    char ch;
    filePointer = fopen(fileName, "r");    // Opening the File

    if (NULL == filePointer)
    {
        printf("file can't be opened \n");  // Prints if file is unable to open.
        exit(0);
    }

    
    int s = 0;

    for(int var = 0; var < frameSize; var++)
           adding_Node(-2);   // Adding dummy values into frame.
    
    struct MainFrame *last = NULL;
    struct MainFrame *Current_Node = head; 
    while (Current_Node != NULL && Current_Node->next != NULL) 
    Current_Node = Current_Node->next;  // Moving to end
    
    last = Current_Node;
    Current_Node->next = head;

   
    while((fscanf(filePointer, "%x %c", &value, &operation)) != EOF)
    {
        //  value = strtoul(input, NULL, 10);
         if((strcmp(fileName, "gcc.txt") == 0) || (strcmp(fileName, "bzip.txt") == 0))
         {
        

         
       // value=checkforHexa(input);
       value=value/PAGE_SIZE;  // Converting the hexadecimal to the page number

       

        }
        
   struct MainFrame *check = checkIfAlreadyPresent(value, last); // Returns null or node based on the ablove condition.
            if (check == NULL)
            { 
                Current_Node = Current_Node->next;
                Current_Node->valuetoBeEntered = value;
               
                if (operation == 'W')     // Comapring Operation
                            Current_Node->diskWrite = 1; 
        
                else
                    Current_Node->diskWrite = 0;
                
             //   printf("%d\n",value);
                pageFaults++;
                
                    diskReadCount++;     // Incrementing the disk read count
                
                 if (Current_Node->diskWrite == 1) 
                  diskwriteCount++;  // Incrementing the disk write count
                
            }   
            else 
            if (operation == 'W')  // Comapring Operation
                Current_Node->diskWrite = 1;// Making bit dirty.
         }

//printf("%d pageFaults \n", pageFaults);  // Prints Page Faults
    last->next = NULL;
struct MainFrame *temporaryNode = head;
printf("Contents of Page Frame \n");
    while (temporaryNode != NULL)
    {
        printf("%x \t", temporaryNode->valuetoBeEntered);  // Prints Contents
        temporaryNode = temporaryNode->next;
    }
    printf("\n");
    printf("No of readings :%d \n", diskReadCount);  // Prints Read Count

    printf("No of writing :%d \n", diskwriteCount);
    fclose(filePointer);
}
// unsigned int checkforHexa(char[] input){
//    // char input[20];
//   //  sprintf(input, "%x", value);
//         for (int i = 0; i<5; i++) {
//         if(!isxdigit(input[i]))
//         value=value/4096;
//         return value;
//         }
//         return value;
// }

struct MainFrame *searchForNode(struct MainFrame *head)
{
    int minimum = head->recentlyUsed;  // Declaring Variables
    struct MainFrame *pos = head;
    struct MainFrame *temporaryNode = head;
    while (temporaryNode != NULL)
    {
        if (temporaryNode->recentlyUsed < minimum)
        {
            minimum = temporaryNode->recentlyUsed;
            pos = temporaryNode;
        }
        temporaryNode = temporaryNode->next;
    }
    return pos;
}
void perform_LRU(char *fileName, int frameSize)
{

    int diskwriteCount = 0;// Declaring Variables
    int diskReadCount=0;
    signed int value;
    char operation;
    FILE *filePointer;
    char ch;

    // Opening file in reading mode
    filePointer = fopen(fileName, "r");

    if (NULL == filePointer)
    {
        printf("file can't be opened \n");
        exit(0);
    }
 
    for (int var = 0; var < frameSize; var++)
    {
        adding_Node(-2);
    }
    struct MainFrame *last = NULL;
    struct MainFrame *Current_Node = head;
    while (Current_Node != NULL && Current_Node->next != NULL)
    {
        Current_Node = Current_Node->next;
    }
    last = Current_Node;

    int pageFaults = 0;// Declaring Variables
    int index = 0;
    long lastUsedTime = 0;
    int counter = 0;

    while ((fscanf(filePointer, "%x %c", &value, &operation)) != EOF)
    {
        if((strcmp(fileName, "gcc.txt") == 0) || (strcmp(fileName, "bzip.txt") == 0))
         {
         value=value/PAGE_SIZE;  // Converting the hexadecimal to the page number
         }
            struct MainFrame *found = checkIfAlreadyPresent(value, last); // Returns null or node based on the ablove condition.
            if (found != NULL)
            {
                counter++;
                found->recentlyUsed = counter;
                // if (operation == 'W')
                //     found->diskWrite = 1;
                
            }
            else
            {
                struct MainFrame *pos = searchForNode(head); 
                counter++;
                pageFaults++;
                
                    diskReadCount++;  // Incrementing the disk read count
                
                pos->valuetoBeEntered = value;
                pos->recentlyUsed = counter;
                
                
                if (operation == 'W') { // Comapring operatiom
                pos->diskWrite = 1;   // Making bit dirty.
         }
                
                else
                    pos->diskWrite = 0;
                
                if (pos->diskWrite == 1)
                    diskwriteCount++;   // Incrementing the disk write count
                
                
            }
        
    }
    last->next = NULL;
    struct MainFrame *temporaryNode = head;
   // printf("%d pageFaults \n", pageFaults);   // Prints Page Faults
    printf("Contents of Page Frame \n");
    while (temporaryNode != NULL)
    {
        printf("%x \t", temporaryNode->valuetoBeEntered); // Prints Contents
        temporaryNode = temporaryNode->next;
    }
    printf("\n");
    printf("No of readings :%d \n", diskReadCount); // Prints Read Count

    printf("No of writings :%d \n", diskwriteCount); // Prints Writings Count
    fclose(filePointer);
}
